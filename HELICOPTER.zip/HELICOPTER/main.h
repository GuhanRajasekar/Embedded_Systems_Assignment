int debug[100];
