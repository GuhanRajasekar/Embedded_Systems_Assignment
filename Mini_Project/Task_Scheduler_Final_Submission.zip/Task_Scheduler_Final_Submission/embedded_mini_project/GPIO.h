void Init_PortAB(void);       // Function to initialize Ports A and B
void Init_PortC(void);        // Function to initialize Port C
void Init_PortE(void);        // Function to initialize Port E
void Init_PortF(void);        // Function to initialize Port F
